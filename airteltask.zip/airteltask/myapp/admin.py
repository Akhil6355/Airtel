from django.contrib import admin
from .models import plans
# Register your models here.
@admin.register(plans)
class UserAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'mobile_number', 'city', 'house_no')