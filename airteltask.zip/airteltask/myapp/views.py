from django.shortcuts import render
from .models import plans
# Create your views here.
def airtel_plans(request):
    return render(request, "plans.html")

def forms(request):
    if request.method == "POST":
        name = request.POST.get('name')
        mobile_number = request.POST.get('mobile_number')
        city = request.POST.get('city')
        house_no = request.POST.get('house_no')
        data = plans(name=name,mobile_number=mobile_number,city=city,house_no=house_no)
        data.save()
    return render(request, "forms.html")    